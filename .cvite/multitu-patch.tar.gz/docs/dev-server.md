# Development server

The first executable vertical slice of CVite is available through:

```console
cvite run app.c
```

For a project directory, CVite discovers exactly one of `main.c` or
`src/main.c` as the entry translation unit:

```console
cvite run .
```

Application arguments follow `--`:

```console
cvite run . -- --level arena.json
```

Application source remains ordinary C. The development server does not require
CVite headers, macros, annotations, state APIs, allocators, or lifecycle
callbacks.

## Current loop

On startup, CVite:

1. locates `compile_commands.json` or `build/compile_commands.json` near the
   project;
2. asks libclang for every C compile command in the entry program and
   normalizes each translation unit's project flags;
3. invokes Clang 18 separately for each translation unit, producing LLVM IR and
   a Make-style dependency file;
4. applies `cvite-provenance` to each module before linking, canonicalizing
   translation-unit-local function and storage identities from the original
   source path;
5. links the canonical modules with `llvm-link` into one program IR module;
6. applies `cvite-lowering`, `cvite-baseline`, and
   `cvite-baseline-manifest` to the linked program;
7. emits one position-independent object and links it into the CVite process
   with LLVM ORC/JITLink;
8. registers compiler-generated stable functions and persistent storage;
9. calls the transformed program's real C `main` on the process main thread;
10. watches every translation unit, the compilation database, and every
    non-system header reported by Clang.

CVite watches dependency **directories** and filters events by file name. This
continues to work when an editor saves through an atomic rename instead of
writing the original inode in place.

## Multi-translation-unit refresh

The first multi-TU implementation uses a deliberately conservative
project-wide invalidation boundary:

```text
one source/header/configuration file changes
                  │
                  ▼
      rebuild every translation unit
                  │
                  ▼
       llvm-link one candidate program
                  │
                  ▼
 validate all function/storage manifests
                  │
                  ▼
 publish one immutable dispatch snapshot
```

This means a failed compile, link, ABI check, or storage-layout check publishes
nothing. All calls continue through the previous complete generation. A
successful candidate may replace functions from several translation units, but
readers can observe only the complete old or complete new target set.

Linking IR before the baseline/candidate transform also lets LLVM resolve normal
cross-TU C declarations and definitions. CVite records each internal function,
file-static variable, and static local's original source path before the link,
so identical local names in different `.c` files retain distinct stable
identities after `llvm-link` renames them internally.

Fine-grained TU invalidation and changed-function filtering are later
optimizations; they do not require changing the source model or runtime patch
transaction.

## Candidate behavior

On save, the watcher reloads the active project model, recompiles all selected
translation units, links a candidate program, and runs `cvite-candidate`. The
result is staged in an isolated ORC generation, validated against the active
function and storage registries, and published atomically.

After publication, all candidate dependency files replace the active watch
graph as one set. Headers introduced by the edit therefore become refreshable
immediately, and headers no longer used by any translation unit are removed.
Editing `compile_commands.json` can likewise change per-TU definitions or
include paths and trigger a state-preserving refresh.

A successful edit looks like:

```text
[cvite] invalidated project; rebuilding 4 translation units
[cvite] refreshed 17 functions → generation 4 (48.6 ms)
```

A syntax error in any source or watched header is reported by Clang and followed
by last-known-good behavior:

```text
[cvite] candidate compilation failed for /project/src/physics.c; previous code remains active
```

Cross-TU link failures, ABI changes, and persistent-layout incompatibilities are
rejected in the same way.

## Compilation database

CVite uses Clang's public compilation-database API rather than implementing a
second JSON parser or a second interpretation of C compiler commands. Both the
`arguments` and `command` forms accepted by libclang are supported.

Every selected translation unit retains its own project semantics, including:

- `-D` and `-U` definitions;
- language-dialect flags;
- include, quote, and system include paths;
- target and machine-feature flags;
- warning, extension, sanitizer, and project-specific frontend options.

Relative include, sysroot, response-file, and resource paths are resolved
against the command's recorded working directory. CVite removes the old source,
output, dependency, optimization, debug, PIC, and compile-mode arguments, then
appends its controlled development pipeline. This prevents an old `-o`, `-c`,
`-O3`, or depfile option from escaping the Fast Refresh build boundary.

The initial target-selection rule accepts C commands under the project root and
requires the discovered entry source to be present. Projects whose compilation
database contains several unrelated executables should provide a target-scoped
database for now. Target-aware graph selection is planned before general M2
project support.

When no usable compilation database exists, CVite discovers sibling `.c`
files beside the entry translation unit and compiles them with C11 development
defaults. A compilation database remains the authoritative path for real project
flags and source selection. If an already-active database disappears or no
longer describes the entry program, the candidate is rejected and the previous
code remains active.

## Toolchain selection

Build-tree defaults are embedded by CMake. They can be overridden without
changing application source:

```console
CVITE_CLANG=/usr/bin/clang-18 \
CVITE_OPT=/usr/bin/opt-18 \
CVITE_LLVM_LINK=/usr/bin/llvm-link-18 \
CVITE_PASS_PLUGIN=/path/to/CViteLoweringPass.so \
cvite run .
```

Set `CVITE_VERBOSE=1` to print every compiler and LLVM command.

`cvite doctor` reports the compiler, optimizer, IR linker, pass plugin,
compilation-database capability, and project mode.

## Current constraints

The current command remains an experimental Linux/Clang vertical slice:

- Linux with `inotify`;
- Clang/LLVM 18;
- C11-compatible application code and debug/`-O0` development generation;
- one supported C `main` across the linked translation units;
- whole-program candidate rebuilds rather than incremental TU rebuilds;
- compilation-database C commands under one project root;
- no automatic external library/archive ingestion yet;
- no automatic layout-changing state migration;
- JIT generations retained until process exit.

Changed-TU filtering, target-aware compile-command selection, custom link
inputs, smallest-boundary restart, and generation reclamation are the next
orchestration layers. Project-wide invalidation already propagates every watched
source, header, and compile-database edit across all selected translation units.

## Lifetime policy

The active ORC loader is intentionally retained after the transformed `main`
returns. This keeps JIT code available while normal process-exit and `atexit`
handling runs, and avoids unloading code that a surviving application thread
could still be executing. Epoch/quiescence-based reclamation will eventually
replace this conservative process-lifetime retention.
